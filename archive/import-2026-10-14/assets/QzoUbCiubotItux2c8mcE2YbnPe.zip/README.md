# Nuromova 专家知识能力组 2.0.0

供内部运动表现专家在 Codex 中连续聊天、修订飞书知识，并交接可追溯资料给研发。

## 从这里开始

在 Codex 输入 `$nuromova-expert-coach 开始聊一个案例`，或说“继续上次的话题”。专家只用一个入口，另外三个 Skill 按需协作。

- nuromova-expert-coach：承接话题、挑选知识缺口、维护进度、主动建议阶段整理。
- nuromova-expert-interview：适配 grilling 的自然追问，一次抓一个关键问题，允许换题和停下。
- nuromova-coach-simulator：六专项运动前后输入、条件变式、逐轮证据、回复引用检查及同输入比较。
- nuromova-knowledge-editor：读取原文、整理修改、确认后写入飞书、核验并生成研发资料。

默认案例约 200–350 字，可按需展开。专家认可具体修订稿后即可写入，没有额外负责人审批；讨论和沉默不会自动变成发布授权。全文文章不被替换成零碎摘要。

[飞书统一入口：RAG库知识储备](https://ni4nrbhniif.feishu.cn/wiki/RqDGw7Oo8irVhQkoG5jcUlnSnlb)

## 安装及分享

将分享包中 `skills/` 下四个完整目录放入接收者自己的 Codex skills 目录（通常是 `~/.codex/skills/`，配置了 CODEX_HOME 时使用其 skills 目录）。四个目录保持同级，不只发送 SKILL.md。已有同名 Skill 先备份。

需要 Node.js 20+。在 `nuromova-coach-simulator` 目录执行：

```sh
npm ci --ignore-scripts
npm test
```

接收者须有自己的飞书 CLI 登录与相应知识库权限。分享包不含账号授权，也不赋予知识库访问权限。缺少飞书工具时先配置官方 lark-cli 与配套 lark-doc/lark-wiki skills；本包不复制凭据。

首次在本机已完成依赖安装。若新 Skill 未出现在当前会话的可用列表，可重新打开一个 Codex 会话再选择入口。

## 记录与交付

专家会话数据写入工作目录 `review-data/`；支持读取历史批次和追加进度。它们不随 Skill 分享。重新开始创建新批次，保留旧批次。

飞书按专业文章、产品架构与规则、案例与反例、管理与研发交付四区组织。18 篇专业文章保留全文，初始抽取 150 个章节单元，均待逐点复核。尚未逐条确认的历史资料不会默认标记为可直接上线检索。

研发快照另含完整 Markdown、文档版本索引、知识 JSONL。拥有快照不等于拥有原文权限，后续系统需按权限与审阅状态过滤。

## 当前边界

脚本执行结构与证据校验，不判断科学真伪。真实专家体验仍需试用；本轮不是独立盲测。模拟器没有调用产品模型 API；评审 schema 1.0.0 也不是已冻结的生产后端接口。

安装包依赖锁和 36 项回归检查用于稳定交付。详情见 CODE-REVIEW.md。
