# 2.0.0 迁移说明

旧链接继续可用；现行约定请见 [Coach 规则](../../nuromova-coach-simulator/references/coach-policy.md)。旧版已备份，不再按旧流程执行。
