# 2.0.0 迁移说明

旧链接继续可用；现行约定请见 [飞书定位与维护](../../nuromova-knowledge-editor/references/feishu.md)。旧版已备份，不再按旧流程执行。
